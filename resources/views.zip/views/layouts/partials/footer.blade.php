<footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">
        <div class="text-center text-sm-left d-block d-sm-inline-block col-lg-4 col-12">
            <div class="m-text-center">
                <p class="innovation main-innovation-by">Innovation By</p>
                <p class="innovation innovation-by">PT. Favorit Teknologi Bangsa</p>
            </div>
        </div>
        <div class="col-lg-4 col-12 text-center">
            <a class="vortek-link" href="http://vortek.co.id">www.vortek.co.id</a>
        </div>
        <div class="col-lg-2">
        </div>
        <div class="float-none float-sm-center d-block mt-1 mt-sm-0 text-center col-lg-2 col-12">

                    <img class="footer-logo" src="{{ config('app.url') }}/Logo VORTEK.png" />
                    
        </div>
    </div>
</footer>